# session_store.py
from typing import Dict, List

chat_sessions: Dict[str, List[dict]] = {}
