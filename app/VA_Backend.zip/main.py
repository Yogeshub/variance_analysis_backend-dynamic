# main.py
from fastapi import FastAPI, File, UploadFile,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Dict, Optional,Any
import pandas as pd
import numpy as np
import io
import json
import math
import httpx
import traceback
from dotenv import load_dotenv
import os
from fastapi.responses import StreamingResponse
import asyncio
import win32com.client as win32
from utils.http_client import get_http_client
from openai import OpenAI
# from utils.generate_variance_pdf import generate_variance_pdf
from utils.session_store import chat_sessions
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from io import BytesIO
from docx import Document
from reportlab.pdfgen import canvas
import os
from utils.generate_variance_pdf import generate_variance_pdf_file
from fastapi.responses import StreamingResponse
from utils.generate_variance_pdf_stream import generate_variance_pdf_stream
from utils.pdf_helpers import save_pdf_to_temp
from fastapi.responses import StreamingResponse
import uuid, json, asyncio, httpx, os
import win32com.client

class ChatMessage(BaseModel):
    role: str
    content: str


class ChatStreamRequest(BaseModel):
    session_id: Optional[str] = None
    message: Optional[str] = None
    auto_prompt: Optional[str] = None
    context: Dict  # 👈 single payload container



AUTO_PROMPTS = {
    "explain_variance": "Explain the major variances and their business impact.",
    "key_risks": "Identify key financial and operational risks from the data.",
    "recommendations": "Provide actionable recommendations based on KPIs and variance.",
    "executive_summary": "Create an executive-level summary of overall performance."
}



load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
EMAIL_TO = os.getenv("EMAIL_TO")
EMAIL_CC = os.getenv("EMAIL_CC")
EMAIL_SUBJECT = os.getenv("EMAIL_SUBJECT")


app = FastAPI(title="Financial KPI Variance Analyzer API")
# Only allow your React frontend origins
origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,       # remove "*" wildcard
    allow_credentials=True,      # keep True if you use cookies or auth
    allow_methods=["*"],         # allow GET, POST, etc.
    allow_headers=["*"],         # allow all headers
)


# Known columns (from your CSV)
DATE_COLS = [
    "Date Of Account Opening", "Last Transaction Date", "Transaction Date",
    "Approval/Rejection Date", "Payment Due Date",
    "Last Credit Card Payment Date", "Feedback Date", "Resolution Date"
]
NUM_COLS = [
    "Transaction Amount", "Account Balance", "Loan Amount",
    "Interest Rate", "Credit Limit", "Credit Card Balance", "Minimum Payment Due"
]


# helper: convert numpy/pandas types to native python types recursively
def convert_to_serializable(obj):
    if isinstance(obj, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(obj)
    if isinstance(obj, (np.floating, np.float64, np.float32, np.float16)):
        return float(obj)
    if isinstance(obj, (np.ndarray, list, tuple)):
        return [convert_to_serializable(i) for i in obj]
    if isinstance(obj, dict):
        return {k: convert_to_serializable(v) for k, v in obj.items()}
    if isinstance(obj, pd.Series):
        return convert_to_serializable(obj.tolist())
    if isinstance(obj, pd.DataFrame):
        return convert_to_serializable(obj.to_dict(orient="records"))
    if hasattr(obj, "tolist") and not isinstance(obj, (str, bytes)):
        try:
            return obj.tolist()
        except Exception:
            pass
    # pandas Period (ReportingMonth)
    try:
        import pandas as _pd
        if isinstance(obj, _pd.Period):
            return str(obj)
    except Exception:
        pass
    return obj


# Rule-based explanation logic (kept simple)
def generate_rule_based_explanation(row: dict, rules: List[dict]):
    explanations = []
    for rule in rules:
        metric = rule.get("metric")
        condition = rule.get("condition")
        message = rule.get("message", "")
        if not metric or not condition:
            continue
        try:
            value = row.get(metric, 0)
            # NaN handling
            if value is None or (isinstance(value, float) and math.isnan(value)):
                value = 0
            # numeric cast
            try:
                value_cast = float(value)
            except Exception:
                value_cast = 0
            # safe eval: build expression using value_cast (avoid direct eval of user input)
            expr = f"{value_cast} {condition}"
            if eval(expr):
                explanations.append(message)
        except Exception as e:
            explanations.append(f"(⚠️ Error evaluating rule for {metric}: {e})")
    return " ".join(explanations) if explanations else "No major variance detected."


@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...), rules: UploadFile = File(None)):
    """
    Accepts: CSV file (multipart)
    Optional: rules.json (multipart) to add rule-based explanations
    Returns:
      {
        "kpi_summary": [{label, value}, ...],
        "kpi_trends": { ReportingMonth: [...], "Total Unique Transactions": [...], ... },
        "variance": [{Metric, CurrentMonth, PreviousMonth, Variance, Rule_Based_Explanation?}, ...]
      }
    """
    try:
        content = await file.read()
        # basic safety: if file is empty
        if not content:
            return JSONResponse({"error": "Uploaded file is empty."}, status_code=400)

        # read CSV into pandas
        try:
            df = pd.read_csv(io.BytesIO(content))
        except Exception as e:
            return JSONResponse({"error": f"Failed to parse CSV: {e}"}, status_code=400)

        if df.empty:
            return JSONResponse({"error": "Uploaded CSV contains no rows."}, status_code=400)

        # normalize column names (strip)
        df.columns = [c.strip() for c in df.columns]

        # Preprocess date columns
        for col in DATE_COLS:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

        # Preprocess numeric columns
        for col in NUM_COLS:
            if col in df.columns:
                # coerce non-numeric to NaN
                df[col] = pd.to_numeric(df[col], errors="coerce")

        # Ensure there is a transaction date; fallback to first date-like column
        if "Transaction Date" in df.columns:
            df["ReportingMonth"] = df["Transaction Date"].dt.to_period("M")
        else:
            # try last transaction date
            fallback_col = None
            for c in ["Last Transaction Date", "Date Of Account Opening", df.columns[0]]:
                if c in df.columns:
                    fallback_col = c
                    break
            if fallback_col:
                df[fallback_col] = pd.to_datetime(df[fallback_col], errors="coerce")
                df["ReportingMonth"] = df[fallback_col].dt.to_period("M")
            else:
                return JSONResponse({"error": "No date column found to compute ReportingMonth."}, status_code=400)

        # Build aggregation map dynamically (only include columns present)
        agg_map = {}
        if "Loan ID" in df.columns:
            agg_map["Loan ID"] = "nunique"
        if "Transaction Amount" in df.columns:
            agg_map["Transaction Amount"] = "sum"
        if "Account Balance" in df.columns:
            agg_map["Account Balance"] = "mean"
        if "Loan Amount" in df.columns:
            agg_map["Loan Amount"] = "sum"

        if not agg_map:
            return JSONResponse({"error": "None of the required columns (Loan ID, Transaction Amount, Account Balance, Loan Amount) exist in file."}, status_code=400)

        # Group and compute KPIs
        kpi = df.groupby("ReportingMonth").agg(agg_map).reset_index()

        # rename to friendly KPI labels
        rename_map = {
            "Loan ID": "Total Unique Transactions",
            "Transaction Amount": "Cumulative Transaction Value",
            "Account Balance": "Mean Account Balance",
            "Loan Amount": "Aggregate Loan Disbursed",
        }
        kpi.rename(columns=rename_map, inplace=True)

        # Ensure ReportingMonth is string for JSON
        kpi["ReportingMonth"] = kpi["ReportingMonth"].astype(str)
        kpi = kpi.sort_values("ReportingMonth").reset_index(drop=True)

        # Variance dataframe (copy of kpi and compute pct change columns)
        variance_df = kpi.copy()
        for col in [c for c in kpi.columns if c != "ReportingMonth"]:
            # compute change % only for numeric columns
            try:
                if np.issubdtype(kpi[col].dtype, np.number):
                    variance_df[f"{col} Change %"] = kpi[col].pct_change() * 100
            except Exception:
                # skip columns not numeric
                pass

        # Clean invalid numbers (NaN/inf)
        kpi = kpi.replace([np.inf, -np.inf, np.nan], None)
        variance_df = variance_df.replace([np.inf, -np.inf, np.nan], None)

        # Parse rules file if provided
        rules_list: List[dict] = []
        if rules:
            try:
                raw = await rules.read()
                rules_list = json.loads(raw.decode("utf-8"))
                if not isinstance(rules_list, list):
                    # accept either dict or list
                    rules_list = [rules_list]
            except Exception:
                rules_list = []

        # If rules exist, compute explanation per variance row (use row dict)
        if rules_list:
            # apply (safe) rule-based explanations
            explanations = []
            for idx, row in variance_df.iterrows():
                try:
                    row_dict = row.to_dict()
                    expl = generate_rule_based_explanation(row_dict, rules_list)
                except Exception as e:
                    expl = f"(⚠️ error evaluating rules: {e})"
                explanations.append(expl)
            variance_df["Rule_Based_Explanation"] = explanations
        else:
            variance_df["Rule_Based_Explanation"] = "No rules file uploaded."

        # Prepare kpi_summary (latest month) - ensure safe types
        kpi_summary = []
        if len(kpi) > 0:
            latest = kpi.iloc[-1]
            for label in [
                "Total Unique Transactions",
                "Cumulative Transaction Value",
                "Mean Account Balance",
                "Aggregate Loan Disbursed",
            ]:
                val = latest.get(label, None)
                # convert pandas/numpy types to python
                if isinstance(val, (np.integer, np.int64, np.int32)):
                    val = int(val)
                elif isinstance(val, (np.floating, np.float64, np.float32)):
                    val = float(val)
                # Keep None or value
                kpi_summary.append({"label": label, "value": val if val is not None else 0})
        else:
            # empty KPI; return zeroed summary
            for label in [
                "Total Unique Transactions",
                "Cumulative Transaction Value",
                "Mean Account Balance",
                "Aggregate Loan Disbursed",
            ]:
                kpi_summary.append({"label": label, "value": 0})

        # Prepare kpi_trends (monthly arrays)
        kpi_trends = {"ReportingMonth": kpi["ReportingMonth"].tolist()}
        for label in [
            "Total Unique Transactions",
            "Cumulative Transaction Value",
            "Mean Account Balance",
            "Aggregate Loan Disbursed",
        ]:
            if label in kpi.columns:
                # ensure native python floats/ints
                series = kpi[label].apply(lambda x: None if pd.isna(x) else (int(x) if isinstance(x, (np.integer,)) else float(x) if isinstance(x, (np.floating,)) else x))
                kpi_trends[label] = series.tolist()
            else:
                kpi_trends[label] = []

        # Prepare variance output (list of dicts) using previous month comparison where possible
        variance_out = []
        if len(kpi) >= 2:
            # we can compute current vs previous for KPIs
            latest = kpi.iloc[-1]
            prev = kpi.iloc[-2]
            for label in [
                "Total Unique Transactions",
                "Cumulative Transaction Value",
                "Mean Account Balance",
                "Aggregate Loan Disbursed",
            ]:
                curr = latest.get(label, 0)
                prev_val = prev.get(label, 0)
                try:
                    curr_f = float(curr) if curr is not None else 0.0
                except Exception:
                    curr_f = 0.0
                try:
                    prev_f = float(prev_val) if prev_val is not None else 0.0
                except Exception:
                    prev_f = 0.0
                variance_out.append({
                    "Metric": label,
                    "CurrentMonth": curr_f,
                    "PreviousMonth": prev_f,
                    "Variance": round(curr_f - prev_f, 2)
                })
        else:
            # not enough months to compute variance; fill with available values
            for label in [
                "Total Unique Transactions",
                "Cumulative Transaction Value",
                "Mean Account Balance",
                "Aggregate Loan Disbursed",
            ]:
                val = None
                if len(kpi) == 1:
                    val = kpi.iloc[0].get(label, 0)
                try:
                    val_f = float(val) if val is not None else 0.0
                except Exception:
                    val_f = 0.0
                variance_out.append({
                    "Metric": label,
                    "CurrentMonth": val_f,
                    "PreviousMonth": 0.0,
                    "Variance": 0.0
                })

        response = {
            "kpi_summary": kpi_summary,
            "kpi_trends": kpi_trends,
            "variance": variance_out,
        }

        # convert everything to serializable python types recursively
        response_serializable = convert_to_serializable(response)
        return JSONResponse(content=response_serializable)

    except Exception as exc:
        # Log full traceback in backend console to help debugging
        print("=== Exception in /api/analyze ===")
        traceback.print_exc()
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/auto-summary")
async def auto_summary(payload: dict):
    prompt = f"""
Summarize key insights, risks, and recommendations:
{json.dumps(payload, indent=2)}
"""

    headers = {"Authorization": f"Bearer {GROQ_API_KEY}"}

    async with httpx.AsyncClient(verify=False, timeout=60) as client:
        res = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            json={
                "model": "llama-3.3-70b-versatile",
                "messages": [{"role": "user", "content": prompt}],
            },
            headers=headers,
        )
        return {"summary": res.json()["choices"][0]["message"]["content"]}







GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"

chat_sessions = {}

@app.post("/api/chat/stream")
async def stream_chat(payload: ChatStreamRequest):
    """
    Stream AI assistant responses for Ask AI chat.
    Supports session memory, context, and streaming responses.
    """

    # 1️⃣ Session handling
    session_id = payload.session_id or str(uuid.uuid4())
    if session_id not in chat_sessions:
        chat_sessions[session_id] = []

    history = chat_sessions[session_id]

    # 2️⃣ Resolve user message (manual OR auto prompt)
    user_message = payload.message
    if payload.auto_prompt:
        user_message = AUTO_PROMPTS.get(payload.auto_prompt)

    if not user_message:
        return {"error": "Message or auto_prompt required"}

    # 3️⃣ System grounding (ONCE per session)
    context_data = payload.context or {}  # Safe default if context missing
    system_prompt = f"""
You are a senior financial analyst AI.

STRICT RULES:
- Use ONLY the provided data
- No hallucination
- Be concise and analytical

CONTEXT DATA:
{json.dumps(context_data, indent=2)}
"""
    # Append system prompt only if not already in session history
    if not any(m["role"] == "system" for m in history):
        history.append({"role": "system", "content": system_prompt})

    # 4️⃣ Append user message to history
    history.append({"role": "user", "content": user_message})

    # 5️⃣ Prepare payload for AI model (GROQ)
    groq_payload = {
        "model": "llama-3.3-70b-versatile",
        "stream": True,
        "messages": history,
    }

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }

    # 6️⃣ Event generator for streaming
    async def event_generator():
        assistant_reply = ""

        async with httpx.AsyncClient(verify=False, timeout=120) as client:
            async with client.stream(
                "POST",
                GROQ_URL,
                headers=headers,
                json=groq_payload,
            ) as response:

                async for line in response.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue

                    data = line.replace("data:", "").strip()
                    if data == "[DONE]":
                        break

                    try:
                        parsed = json.loads(data)
                        delta = (
                            parsed.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content")
                        )

                        if delta:
                            assistant_reply += delta
                            yield delta
                    except Exception:
                        continue

        # 7️⃣ Save assistant reply to session history
        history.append({"role": "assistant", "content": assistant_reply})

    # 8️⃣ Return streaming response
    return StreamingResponse(
        event_generator(),
        media_type="text/plain",
        headers={"X-Session-ID": session_id},  # Frontend can store session ID
    )

@app.post("/api/chat/reset/{session_id}")
def reset_chat(session_id: str):
    chat_sessions.pop(session_id, None)
    return {"status": "reset", "session_id": session_id}


class SendMailRequest(BaseModel):
    subject: Optional[str] = None
    body: Optional[str] = None
    kpi_summary: List[Dict[str, Any]]
    variance: List[Dict[str, Any]]
    ai_insight: Optional[str] = None





@app.post("/api/send-mail")
async def send_mail(payload: SendMailRequest):
    # Read from environment
    to_email = os.getenv("EMAIL_TO")
    cc_email = os.getenv("EMAIL_CC")
    subject = payload.subject or os.getenv("EMAIL_SUBJECT", "Financial KPI Report")

    if not to_email:
        return JSONResponse(
            {"error": "EMAIL_TO not configured in environment"},
            status_code=500
        )

    pdf_buffer = generate_variance_pdf_stream(
        payload.kpi_summary,
        payload.variance,
        payload.ai_insight
    )

    pdf_path = save_pdf_to_temp(pdf_buffer)

    outlook = win32com.client.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)

    mail.To = to_email
    if cc_email:
        mail.CC = cc_email

    mail.Subject = subject
    mail.Body = payload.body or "Please find attached the KPI variance report."

    mail.Attachments.Add(pdf_path)
    mail.Send()

    return {
        "status": "success",
        "message": f"Email sent successfully to {to_email}"
    }


class AIRequest(BaseModel):
    variance: Optional[List[dict]]


@app.post("/api/generate-ai")
async def generate_ai(req: AIRequest):
    
    if not req.variance:
        return JSONResponse(
            {"error": "Variance data required"},
            status_code=400
        )
    
    prompt = f"You are a financial analyst. Analyze KPI variance data: {json.dumps(req.variance or [])}"
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}"}
    payload = {"model": "llama-3.3-70b-versatile", "messages": [{"role": "user", "content": prompt}]}

    try:
        async with httpx.AsyncClient(verify=False, timeout=60) as client:
            resp = await client.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            text = data.get("choices", [{}])[0].get("message", {}).get("content") or data.get("text") or str(data)
            return {"text": text}
    except Exception as e:
        print("Error calling LLM provider:", e)
        return JSONResponse({"error": str(e)}, status_code=500)


class KPISummaryItem(BaseModel):
    label: str
    value: Any   # number or string

class DownloadReportRequest(BaseModel):
    kpi_summary: List[KPISummaryItem]
    variance: List[Dict[str, Any]]
    ai_insight: Optional[str] = None

@app.post("/api/download-report")
async def download_report(payload: DownloadReportRequest, format: str = "pdf"):

    buffer = generate_variance_pdf_stream(
        payload.kpi_summary,
        payload.variance,
        payload.ai_insight
    )

    return StreamingResponse(
        buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=report.pdf"}
    )